#ifndef MACRO_H_
#define MACRO_H_

/************SIZE MAP************/
#define MAP_SIZE  8

#endif //MACRO_H_