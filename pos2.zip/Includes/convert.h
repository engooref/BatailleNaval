#ifndef CONVERT_H_
#define CONVERT_H_

char* IntToStr(int number);
int StrToInt(char* str);

#endif //CONVERT_H_