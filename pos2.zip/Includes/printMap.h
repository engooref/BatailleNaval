#ifndef PRINTMAP_H_
#define PRINTMAP_H_

#include "IOConsole.h"

void print_maps(char* mapMe, char* mapEnnemy);

#endif //PRINTMAP_H_